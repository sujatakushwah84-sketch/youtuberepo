/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Search, 
  Youtube, 
  BarChart3, 
  Layout, 
  FileText, 
  Zap, 
  Target, 
  Loader2, 
  Copy, 
  Check,
  AlertCircle,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { cn } from './lib/utils';

// Initialize Gemini
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export default function App() {
  const [input, setInput] = useState('');
  const [currentDescription, setCurrentDescription] = useState('');
  const [videoDuration, setVideoDuration] = useState('');
  const [targetLanguage, setTargetLanguage] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [report, setReport] = useState<string | null>(null);
  const [optimizedTemplate, setOptimizedTemplate] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [templateCopied, setTemplateCopied] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);

  const analyzeVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setIsAnalyzing(true);
    setError(null);
    setReport(null);
    setOptimizedTemplate(null);

    try {
      const model = "gemini-3-flash-preview";
      const isUrl = input.startsWith('http');
      
      const prompt = `
        You are an expert YouTube SEO strategist. 
        TARGET VIDEO: ${input}
        ${currentDescription ? `CURRENT DESCRIPTION PROVIDED BY USER: \n${currentDescription}\n` : ''}
        ${videoDuration ? `ACTUAL VIDEO DURATION: ${videoDuration}\n` : ''}
        ${targetLanguage ? `TARGET LANGUAGE: ${targetLanguage}\n` : ''}
        
        CRITICAL INSTRUCTION: 
        1. If a "CURRENT DESCRIPTION PROVIDED BY USER" is present above, you MUST use that as the primary source for Section 3 analysis.
        2. If "ACTUAL VIDEO DURATION" is provided, you MUST ensure all timestamps in the analysis and template fall within this duration.
        3. LANGUAGE SPECIFICITY & DETECTION: 
           - **ROBUST DETECTION STRATEGY**: You MUST analyze the Title, the Description, and any available transcript or video metadata to determine the primary language. 
           - Look for multi-lingual patterns (e.g., "Hinglish", "Spanglish"). If the video uses a mix, the "Optimized Content Package" should reflect that natural mix to maintain audience engagement.
           - If "TARGET LANGUAGE" is provided, use that for the "Optimized Content Package" (Part 2).
           - Otherwise, the "Optimized Content Package" (titles, description, tags) MUST be in the SAME language as the video (e.g., if the video is in Hindi, generate Hindi titles/description; if English, generate English).
           - The "Comprehensive Analysis" (Part 1) should remain in English for professional reporting.
        4. If the input is a URL, you MUST use the "urlContext" tool to visit the page and extract the ACTUAL title, ACTUAL duration, and any other metadata you can find. 
        4. DURATION CHECK: You MUST identify the exact duration of the video. 
        5. TIMESTAMP INTEGRITY: Do NOT hallucinate timestamps. 
           - If the video is short (e.g., under 1 minute), do NOT generate 10 minutes of timestamps. 
           - Timestamps in the "Optimized Template" MUST fit within the ACTUAL duration of the video. 
           - If the video is under 2 minutes, only provide 2-3 high-level timestamps or mark as "Not applicable for short-form content".
        5. Do NOT guess or hallucinate details based on the URL string. 
        6. If you cannot access the specific video details via URL, use "googleSearch" to find the most recent metadata for this video title/channel.
        7. Your analysis MUST be based on the REAL content of the video provided.

        PART 1: COMPREHENSIVE ANALYSIS
        —————————————————————————————
        SECTION 1 — VIDEO METADATA ANALYSIS
        1.1 VIDEO TITLE BREAKDOWN (Analyze the ACTUAL title)
        1.2 VIDEO TAGS (Identify tags used)
        1.3 VIDEO CATEGORY & LANGUAGE

        SECTION 2 — THUMBNAIL ANALYSIS (Describe the ACTUAL thumbnail if visible, or search for it)
        2.1 VISUAL COMPOSITION
        2.2 THUMBNAIL TEXT
        2.3 BRAND CONSISTENCY
        2.4 PSYCHOLOGICAL TRIGGERS
        2.5 THUMBNAIL PERFORMANCE SIGNALS

        SECTION 3 — DESCRIPTION BOX DEEP ANALYSIS (Analyze the ACTUAL description)
        3.1 ABOVE-THE-FOLD SECTION
        3.2 FULL DESCRIPTION STRUCTURE — LAYOUT MAP
        3.3 KEYWORD PLACEMENT IN DESCRIPTION
        3.4 TIMESTAMPS / CHAPTERS ANALYSIS
        3.5 LINKS PLACEMENT STRATEGY
        3.6 RELATED VIDEOS & PLAYLISTS
        3.7 HASHTAG STRATEGY

        SECTION 4 — ENGAGEMENT & RETENTION SIGNALS
        SECTION 5 — COMPETITOR BENCHMARKING MATRIX
        SECTION 6 — ACTIONABLE OPTIMISATION RECOMMENDATIONS

        PART 2: OPTIMIZED CONTENT PACKAGE (Brand new, ready-to-use content)
        SECTION 7 — OPTIMIZED METADATA & DESCRIPTION TEMPLATE
        7.1 OPTIMIZED TITLE VARIATIONS
        7.2 READY-TO-USE DESCRIPTION (BLOCK-BY-BLOCK)
        7.3 SUGGESTED VIDEO TIMESTAMPS / CHAPTERS (Must be relevant to content and fall within the ACTUAL video duration)
        7.4 OPTIMIZED TAG SET
        7.5 LINK TEMPLATE STRATEGY

        Important: Use the [ANALYSIS_START], [ANALYSIS_END], [TEMPLATE_START], and [TEMPLATE_END] markers.
      `;

      const response = await genAI.models.generateContent({
        model: model,
        contents: prompt,
        config: {
          tools: [
            { googleSearch: {} },
            { urlContext: {} }
          ],
          toolConfig: { 
            includeServerSideToolInvocations: true 
          }
        },
      });

      if (response.text) {
        const text = response.text;
        const analysisMatch = text.match(/\[ANALYSIS_START\]([\s\S]*?)\[ANALYSIS_END\]/);
        const templateMatch = text.match(/\[TEMPLATE_START\]([\s\S]*?)\[TEMPLATE_END\]/);

        if (analysisMatch) setReport(analysisMatch[1].trim());
        if (templateMatch) setOptimizedTemplate(templateMatch[1].trim());
        
        // Fallback if markers are missing
        if (!analysisMatch && !templateMatch) {
          setReport(text);
        }

        setTimeout(() => {
          resultsRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        throw new Error("No analysis generated. Please try again.");
      }
    } catch (err: any) {
      console.error("Analysis error:", err);
      setError(err.message || "An error occurred during analysis. Please check the URL and try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const copyToClipboard = async (e: React.MouseEvent, text: string, setFn: (v: boolean) => void) => {
    e.preventDefault();
    e.stopPropagation();
    if (!text) return;
    
    try {
      await navigator.clipboard.writeText(text);
      setFn(true);
      setTimeout(() => setFn(false), 2000);
    } catch (err) {
      console.error("Failed to copy:", err);
      // Fallback for environments where clipboard API might be restricted
      try {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        setFn(true);
        setTimeout(() => setFn(false), 2000);
      } catch (fallbackErr) {
        console.error("Fallback copy failed:", fallbackErr);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-gray-100 font-sans selection:bg-red-500/30">
      {/* Header */}
      <header className="border-b border-white/10 bg-[#0f0f0f]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-red-600 p-1.5 rounded-lg">
              <Youtube className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              SEO Strategist
            </h1>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-400">
            <span className="hover:text-white transition-colors cursor-pointer">Metadata</span>
            <span className="hover:text-white transition-colors cursor-pointer">Thumbnails</span>
            <span className="hover:text-white transition-colors cursor-pointer">Analytics</span>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-bold uppercase tracking-wider mb-6">
              <Sparkles className="w-3 h-3" />
              AI-Powered Content Intelligence
            </div>
            <h2 className="text-4xl md:text-6xl font-extrabold mb-6 tracking-tight leading-tight">
              Analyze Any Video. <br />
              <span className="text-red-600">Dominate</span> the Algorithm.
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-10">
              Get a comprehensive SEO audit, thumbnail analysis, and actionable growth strategy for any YouTube video in seconds.
            </p>
          </motion.div>

          {/* Search Input */}
          <motion.form 
            onSubmit={analyzeVideo}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="relative max-w-2xl mx-auto space-y-4"
          >
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-orange-600 rounded-2xl blur opacity-25 group-focus-within:opacity-50 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative flex items-center bg-[#1a1a1a] border border-white/10 rounded-2xl overflow-hidden p-2">
                <div className="pl-4 text-gray-500">
                  <Search className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  placeholder="Paste YouTube URL or Title + Channel Name..."
                  className="flex-1 bg-transparent border-none focus:ring-0 px-4 py-3 text-white placeholder:text-gray-600"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={isAnalyzing}
                />
                <button
                  type="submit"
                  disabled={isAnalyzing || !input.trim()}
                  className={cn(
                    "px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all duration-200",
                    isAnalyzing || !input.trim() 
                      ? "bg-gray-800 text-gray-500 cursor-not-allowed" 
                      : "bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/20 active:scale-95"
                  )}
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      Analyze
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="flex justify-center">
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="text-xs text-gray-500 hover:text-gray-300 flex items-center gap-1 transition-colors"
              >
                {showAdvanced ? "Hide" : "Show"} Advanced Options (Paste Description)
              </button>
            </div>

            <AnimatePresence>
              {showAdvanced && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden space-y-4"
                >
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <label className="text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-1 block">Video Duration (Optional)</label>
                      <input
                        type="text"
                        placeholder="e.g. 0:47 or 10:05"
                        className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2 text-sm text-white placeholder:text-gray-600 focus:ring-1 focus:ring-red-600 focus:border-red-600"
                        value={videoDuration}
                        onChange={(e) => setVideoDuration(e.target.value)}
                        disabled={isAnalyzing}
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[10px] uppercase tracking-widest text-gray-500 font-bold block">Target Language (Optional)</label>
                        <span className="text-[8px] bg-red-600/20 text-red-500 px-1.5 py-0.5 rounded-full font-bold uppercase tracking-tighter">Enhanced Detection Active</span>
                      </div>
                      <input
                        type="text"
                        placeholder="e.g. Hindi, English, Spanish"
                        className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2 text-sm text-white placeholder:text-gray-600 focus:ring-1 focus:ring-red-600 focus:border-red-600"
                        value={targetLanguage}
                        onChange={(e) => setTargetLanguage(e.target.value)}
                        disabled={isAnalyzing}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-1 block">Current Description (Optional)</label>
                    <textarea
                      placeholder="Paste current video description here for 100% accuracy..."
                      className="w-full bg-[#1a1a1a] border border-white/10 rounded-2xl p-4 text-sm text-white placeholder:text-gray-600 focus:ring-1 focus:ring-red-600 focus:border-red-600 min-h-[120px]"
                      value={currentDescription}
                      onChange={(e) => setCurrentDescription(e.target.value)}
                      disabled={isAnalyzing}
                    />
                    <p className="mt-2 text-[10px] text-gray-500 italic">
                      Note: Enhanced detection analyzes Title, Description, and Metadata to accurately identify multi-lingual content like "Hinglish".
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 flex items-center gap-2 text-red-500 text-sm justify-center"
              >
                <AlertCircle className="w-4 h-4" />
                {error}
              </motion.div>
            )}
          </motion.form>
        </section>

        {/* Features Grid (Visible when not analyzing/no report) */}
        {!isAnalyzing && !report && (
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            {[
              { 
                icon: BarChart3, 
                title: "Metadata Audit", 
                desc: "Deep dive into titles, tags, and keywords for maximum reach." 
              },
              { 
                icon: Layout, 
                title: "Thumbnail Review", 
                desc: "Visual composition and psychological trigger analysis." 
              },
              { 
                icon: Zap, 
                title: "Growth Strategy", 
                desc: "Prioritized action items to boost CTR and retention." 
              }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="p-6 rounded-2xl bg-[#1a1a1a] border border-white/5 hover:border-white/10 transition-colors group"
              >
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-4 group-hover:bg-red-600/10 transition-colors">
                  <feature.icon className="w-6 h-6 text-gray-400 group-hover:text-red-500 transition-colors" />
                </div>
                <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </section>
        )}

        {/* Loading State */}
        <AnimatePresence>
          {isAnalyzing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-20 space-y-6"
            >
              <div className="relative">
                <div className="w-20 h-20 border-4 border-red-600/20 border-t-red-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Youtube className="w-8 h-8 text-red-600" />
                </div>
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-xl font-bold">Scanning Content...</h3>
                <p className="text-gray-500 animate-pulse">Our AI strategist is dissecting the algorithm signals.</p>
              </div>
              <div className="flex gap-2">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-2 h-2 bg-red-600 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.2}s` }}></div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results Section */}
        <AnimatePresence>
          {report && (
            <motion.div
              ref={resultsRef}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <div className="flex flex-col gap-8">
                {/* Analysis Section */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                        <BarChart3 className="w-5 h-5 text-green-500" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">SEO Analysis</h3>
                        <div className="flex items-center gap-2">
                          <p className="text-sm text-gray-500">Deep dive into current performance</p>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-green-500/10 text-green-500 font-bold uppercase tracking-tighter border border-green-500/20">Verified Report</span>
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => copyToClipboard(e, report || "", setCopied)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-all text-sm font-medium"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 text-green-500" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          Copy Analysis
                        </>
                      )}
                    </button>
                  </div>
                  <div className="bg-[#1a1a1a] border border-white/10 rounded-3xl p-8 shadow-2xl overflow-hidden">
                    <div className="markdown-body">
                      <Markdown>{report}</Markdown>
                    </div>
                    <div className="mt-8 pt-8 border-t border-white/5 flex items-center justify-between text-[10px] text-gray-600 uppercase tracking-widest font-bold">
                      <span>YouTube SEO Strategist v2.0</span>
                      <span>Generated: {new Date().toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {/* Optimized Template Section */}
                {optimizedTemplate && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center">
                          <Zap className="w-5 h-5 text-red-500" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold">Optimized Content Package</h3>
                          <p className="text-sm text-gray-500">Ready-to-use metadata & description</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => copyToClipboard(e, optimizedTemplate || "", setTemplateCopied)}
                        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 transition-all text-sm font-bold text-white shadow-lg shadow-red-600/20"
                      >
                        {templateCopied ? (
                          <>
                            <Check className="w-4 h-4" />
                            Copied Template
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            Copy Optimized Template
                          </>
                        )}
                      </button>
                    </div>
                    <div className="bg-[#1a1a1a] border border-red-500/20 rounded-3xl p-8 shadow-2xl overflow-hidden relative">
                      <div className="absolute top-0 right-0 p-4">
                        <div className="px-2 py-1 rounded bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-bold uppercase tracking-widest">
                          Optimized
                        </div>
                      </div>
                      <div className="markdown-body">
                        <Markdown>{optimizedTemplate}</Markdown>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Action Footer */}
              <div className="bg-gradient-to-r from-red-600 to-orange-600 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <h4 className="text-2xl font-bold mb-2">Ready to optimize?</h4>
                  <p className="text-white/80">Apply these recommendations to see immediate growth in your impressions and CTR.</p>
                </div>
                <button 
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    setReport(null);
                    setOptimizedTemplate(null);
                    setInput('');
                    setCurrentDescription('');
                    setVideoDuration('');
                    setTargetLanguage('');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-8 py-4 bg-white text-black font-bold rounded-2xl hover:bg-gray-100 transition-colors whitespace-nowrap"
                >
                  Analyze Another Video
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="border-t border-white/5 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6 opacity-50">
            <Youtube className="w-5 h-5" />
            <span className="font-bold tracking-tighter">SEO STRATEGIST</span>
          </div>
          <p className="text-gray-600 text-sm">
            Powered by Gemini AI Intelligence. Created by <span className="text-gray-400 font-medium">Amit Kushwah</span>.
          </p>
          <div className="mt-8 flex justify-center gap-6 text-gray-500 text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">API</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
